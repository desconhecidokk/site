import { TinaAdmin } from 'tinacms';

export default TinaAdmin;
